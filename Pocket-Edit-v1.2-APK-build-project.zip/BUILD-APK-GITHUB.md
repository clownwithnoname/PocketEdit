# Build an installable Pocket Edit APK (GitHub Actions)

1. Create a **private** GitHub repository. The project contains an app signing keystore and its password, so never upload it to a public repository.
2. Upload all contents of this archive to the repository root, including the hidden `.github/workflows/build-apk.yml` directory.
3. In GitHub, open **Actions → Build Pocket Edit APK → Run workflow**.
4. When the run succeeds, download the **Pocket-Edit-1.2-APK** workflow artifact and unzip it to get `Pocket-Edit-1.2.apk`.
5. Transfer the APK to your Android device and install it (allow installs from the file manager if prompted).

No internet permission is requested by the app. GitHub's build runner downloads Android SDK components. The build process is automated but **has not been executed in this environment**.

If the build fails, copy the error log back to this conversation for repair.
