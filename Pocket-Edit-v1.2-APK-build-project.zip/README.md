# Pocket Edit 1.2 — native, offline Android editor

**Install:** Android 8 (API 26) or later. No INTERNET permission, advertising, analytics, network calls, or external libraries. Preview uses the Android system WebView with JavaScript, network access, local file access and content access disabled.

## Toolbar

- **Preview** toggles the rendered view. With Live preview off, it replaces the editor with a static preview; tap Preview again to edit.
- **Live preview** automatically shows the editor and preview together (vertical split) and updates the rendering after changes (~300 ms debounce). Switch it off for static preview. State persists.
- **Open**, **Save**, **Save as** are dedicated buttons. Save as prompts for a different document through Android's file picker; Save updates the existing document when possible.
- **Settings** is a full-width, labeled button for new file, undo, redo, find, select all, the working folder, backup preferences, manual backup and restore, language, editor font, font size, and word wrap.
- Tap the filename to rename the proposed file (you must use Save as afterwards).

## Markdown

`.md`, `.markdown` and `.mdown` are recognized as Markdown. Highlighting and rendered Markdown preview support headings, lists, checkboxes, paragraphs, quotations, horizontal rules, inline code, fenced code, emphasis, links as non-clickable text, and simple tables. Ordinary HTML files render as HTML with scripts and external resources blocked. Other file types preview as escaped plain text. To keep the editor fully offline, Markdown images are shown as placeholders, and raw HTML in Markdown is escaped rather than executed. The preview is not a full CommonMark/GFM implementation.

## Working folder and versioned backups

1. Choose **Settings → Working folder…** and grant access in the Android folder picker. The editor creates or reuses a `bak` subdirectory **inside that folder**. The document picker for Open/Save as starts from your working folder when the provider supports it. Files outside the working folder can still be opened; their backups go into that working folder's `bak`.
2. While the app is active, the default backup interval is **5 minutes** (Settings → Backup interval; enter 0 to disable scheduled backups). Unchanged snapshots are skipped to avoid redundant versions. Settings → Back up now always takes a new snapshot.
3. Each original file has **9 backups by default** (Settings → Backup copies per file, range 1–100). After each new snapshot, the oldest versions for that file are deleted. Snapshots are timestamped UTF-8 source files with `.bak` extension, a stable per-document identifier, and a checksum. Opening a file does not alter it.
4. The app retains the lightweight in-app recovery draft from previous versions. After an unexpected shutdown, it locates the newest *valid* backup for the current document, checks its checksum and encoding, and **prompts whether to restore it or retain the draft**. A restored backup is marked modified until manually saved. If the latest backup is damaged, older ones are checked. You can use **Settings → Restore latest backup…** manually.

Backups are written via Android's Storage Access Framework (SAF) without broad storage permissions; some document providers may not support folder creation, deletion, or persistent access, in which case backup operations display an error. Scheduled backups run **while Pocket Edit is in the foreground**, not as a persistent background job. Save your document normally for permanent changes. The 5 MiB per-file limit applies to snapshots too. Uninstalling removes the in-app draft, but not the `bak` folder stored in your chosen location.

## Other editor features

- Bottom shortcut row: Home, End, Return, Tab, left, right, up, down. Hold left/right for word jumps; hold up/down for repeating visual-line movement.
- Word wrap, text size, and Android monospace / bundled Unifont 17.0.04 / sans / serif fonts.
- HTML (including embedded CSS and JavaScript), CSS, JavaScript, JSON, and Markdown highlighting.
- UTF-8, BOM-marked UTF-16, and original line-ending style are preserved. Binary and undecodable documents are rejected. Files over 5 MiB are rejected.
- Syntax highlighting runs in a worker and applies spans only to visible text. Drafts and backups run on a background I/O thread.

## Build and testing

Set `ANDROID_JAR` to an installed Android SDK platform's `android.jar` and `ANDROID_BUILD_TOOLS` to the corresponding SDK build-tools directory. Run `./build.sh`. Java 8-compatible sources, Android minSdk 26, targetSdk 34. The build compiles JVM tests for cursor editing, syntax scanning and Markdown preview. `AndroidManifest.xml` requests zero permissions. This build increments versionCode to 3/versionName to 1.2; the included keystore and alias are preserved from the 1.1 project for an in-place update.

**Validation performed on this revision:** JVM unit tests, Java source parsing, and a simulated SAF provider test for backup rotation, UTF-8, checksum verification, and fallback from damaged backups. This environment has no Android SDK or device, so compilation of the Android app, installability, keyboard behavior, SAF-provider behavior, and WebView runtime remain unverified.

## Font attribution

Unmodified Unifont 17.0.04 from https://unifoundry.com/pub/unifont/unifont-17.0.04/font-builds/unifont-17.0.04.otf is bundled under SIL OFL 1.1. Attribution and license texts are in `assets/licenses`.

## Signing

The included personal keystore and signing alias are needed for update compatibility. Alias `pocketedit`; password `pocket-edit-local`. Do not publish this keystore. This is a private, locally distributed build, not a Play Store package.
