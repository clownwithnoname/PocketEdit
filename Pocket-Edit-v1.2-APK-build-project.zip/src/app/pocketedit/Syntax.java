package app.pocketedit;
import java.util.*;

/** Linear scanner. Parsing never touches Android views. */
public final class Syntax {
 public static final int COMMENT=0xff7c8d87,STRING=0xffbbd49a,NUMBER=0xffe5bb83,KEYWORD=0xffbc9ce2,TAG=0xff80bddd,PROPERTY=0xffe4b39b;
 static final Set<String> WORDS=new HashSet<>(Arrays.asList("const let var function return if else for while class new true false null undefined import export from async await try catch throw switch case break this typeof default extends void static public private in of do delete instanceof yield".split(" ")));
 public static final class Token {public final int start,end,color;Token(int a,int b,int c){start=a;end=b;color=c;}}
 public static int[] lineStarts(String s){int count=1;for(int i=0;i<s.length();i++)if(s.charAt(i)=='\n')count++;int[] result=new int[count];int k=1;for(int i=0;i<s.length();i++)if(s.charAt(i)=='\n')result[k++]=i+1;return result;}
 static boolean word(char c){return Character.isLetterOrDigit(c)||c=='_'||c=='$'||c=='-';}
 static void add(ArrayList<Token> out,int a,int b,int c){if(a<b)out.add(new Token(a,b,c));}
 static int quoted(String s,int p,int limit){char quote=s.charAt(p++);while(p<limit){char c=s.charAt(p++);if(c=='\\'&&p<limit)p++;else if(c==quote)break;}return p;}
 static int tagEnd(String s,int p){int n=s.length();while(p<n){char c=s.charAt(p);if(c=='\''||c=='"')p=quoted(s,p,n);else {p++;if(c=='>')break;}}return p;}
 static int closing(String s,String needle,int p){for(int i=p;i<=s.length()-needle.length();i++)if(s.regionMatches(true,i,needle,0,needle.length()))return i;return -1;}
 public static ArrayList<Token> scan(String s,String language){ArrayList<Token> out=new ArrayList<>();if(language.equals("Plain text"))return out;
  if(language.equals("Markdown")){markdown(s,out);return out;}
  if(!language.equals("HTML")){code(s,0,s.length(),language.equals("CSS"),out);return out;}
  int p=0;
  while(p<s.length()&&!Thread.currentThread().isInterrupted()){
   if(s.startsWith("<!--",p)){int e=s.indexOf("-->",p+4);e=e<0?s.length():e+3;add(out,p,e,COMMENT);p=e;continue;}
   if(s.charAt(p)=='<'&&p+1<s.length()&&(Character.isLetter(s.charAt(p+1))||"/!?".indexOf(s.charAt(p+1))>=0)){
    int a=p;p=tagEnd(s,p+1);add(out,a,p,TAG);
    int q=a+1;while(q<s.length()&&Character.isLetter(s.charAt(q)))q++;String name=s.substring(a+1,q).toLowerCase(Locale.ROOT);
    if(name.equals("script")||name.equals("style")){int end=closing(s,"</"+name,p);if(end<0)end=s.length();code(s,p,end,name.equals("style"),out);p=end;}
   }else p++;
  }return out;
 }
 static void markdown(String s,ArrayList<Token> out){
   boolean fenced=false;int start=0;
   while(start<s.length()&&!Thread.currentThread().isInterrupted()){
     int end=s.indexOf('\n',start);if(end<0)end=s.length();
     int p=start;while(p<end&&s.charAt(p)==' ')p++;
     if(p+2<end&&(s.startsWith("```",p)||s.startsWith("~~~",p))){add(out,p,end,KEYWORD);fenced=!fenced;}
     else if(fenced)add(out,start,end,STRING);
     else {
       if(p<end&&s.charAt(p)=='#'){int q=p;while(q<end&&s.charAt(q)=='#')q++;if(q<end&&s.charAt(q)==' '){add(out,p,end,TAG);start=end+1;continue;}}
       if(p<end&&s.charAt(p)=='>'){add(out,p,end,COMMENT);start=end+1;continue;}
       while(p<end){char c=s.charAt(p);
         if(c=='`'){int q=s.indexOf('`',p+1);if(q>=0&&q<end){add(out,p,q+1,STRING);p=q+1;continue;}}
         if(c=='*'||c=='_'){int q=s.indexOf(c,p+1);if(q>=0&&q<end){add(out,p,q+1,KEYWORD);p=q+1;continue;}}
         if(c=='['){int q=s.indexOf(']',p+1);if(q>=0&&q<end){add(out,p,q+1,PROPERTY);p=q+1;continue;}}
         p++;
       }
     }
     start=end+1;
   }
 }
 static void code(String s,int p,int end,boolean css,ArrayList<Token> out){while(p<end&&!Thread.currentThread().isInterrupted()){
   int a=p;char c=s.charAt(p);
   if(c=='/'&&p+1<end&&s.charAt(p+1)=='*'){int e=s.indexOf("*/",p+2);p=e<0?end:Math.min(end,e+2);add(out,a,p,COMMENT);}
   else if(!css&&c=='/'&&p+1<end&&s.charAt(p+1)=='/'){int e=s.indexOf('\n',p+2);p=e<0?end:Math.min(end,e);add(out,a,p,COMMENT);}
   else if(c=='"'||c=='\''||c=='`'){p=quoted(s,p,end);add(out,a,p,STRING);}
   else if(Character.isDigit(c)||c=='#'){p++;while(p<end&&(word(s.charAt(p))||s.charAt(p)=='.'))p++;add(out,a,p,NUMBER);}
   else if(word(c)){p++;while(p<end&&word(s.charAt(p)))p++;int q=p;while(q<end&&Character.isWhitespace(s.charAt(q)))q++;if(q<end&&s.charAt(q)==':')add(out,a,p,PROPERTY);else if(WORDS.contains(s.substring(a,p)))add(out,a,p,KEYWORD);}
   else p++;
  }}
}
