import app.pocketedit.Syntax;
import java.util.*;
public class SyntaxTest {
 static void check(boolean condition){if(!condition)throw new AssertionError();}
 public static void main(String[] args){
  ArrayList<Syntax.Token> ts=Syntax.scan("const name = \"hi\"; // note\n","JavaScript");check(ts.size()==3);
  check(ts.get(0).color==Syntax.KEYWORD&&ts.get(1).color==Syntax.STRING&&ts.get(2).color==Syntax.COMMENT);
  String embedded="<style>body {color:red;}</style><script>const x=1;</script>";
  ts=Syntax.scan(embedded,"HTML");check(ts.size()==7);
  int last=0;for(Syntax.Token t:ts){check(t.start>=last&&t.end<=embedded.length());last=t.end;}
  check(Syntax.scan("/* unterminated","CSS").get(0).end==15);
  check(Syntax.scan("<script>const x=1;","HTML").size()==3);
  check(Syntax.scan("<p title=\">\">text</p>","HTML").size()==2);
  check(Syntax.scan("hello","Plain text").isEmpty());
  check(!Syntax.scan("# Heading\n- **bold** and `code`", "Markdown").isEmpty());
  check(Syntax.scan("İ<style>p{color:red}</style>","HTML").size()==3);
  check(Arrays.equals(Syntax.lineStarts("a\nb\n"),new int[]{0,2,4}));
  StringBuilder big=new StringBuilder();for(int i=0;i<20000;i++)big.append("const name = \"hi\"; // note\n");
  long start=System.nanoTime();check(Syntax.scan(big.toString(),"JavaScript").size()==60000);
  System.out.println("Syntax and line-index tests passed; 520k-character scan: "+((System.nanoTime()-start)/1000000)+"ms");
  check(Syntax.scan("\""+new String(new char[80000]).replace('\0','a')+"\"","JSON").size()==1);
 }
}
