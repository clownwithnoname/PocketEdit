import app.pocketedit.EditorLogic;
public class EditorLogicTest {
 static void eq(Object a,Object b){if(!a.equals(b))throw new AssertionError(a+" != "+b);}
 public static void main(String[] args){
   String s="alpha beta gamma";
   eq(EditorLogic.move(s,0,true,true),5);eq(EditorLogic.move(s,5,true,true),10);
   eq(EditorLogic.move(s,10,false,true),6);eq(EditorLogic.move(s,6,false,true),0);
   eq(EditorLogic.move(s,0,false,true),0);eq(EditorLogic.move(s,s.length(),true,true),s.length());
   eq(EditorLogic.move("a😀b",1,true,false),3);eq(EditorLogic.move("a😀b",3,false,false),1);
   eq(EditorLogic.home("abc\ndef",4),4);eq(EditorLogic.home("abc\ndef",0),0);
   eq(EditorLogic.end("abc\ndef",0),3);eq(EditorLogic.end("abc\ndef",5),7);
   eq(EditorLogic.indentation("a\n\t  hi",7),"\t  ");
   eq(EditorLogic.move("one.two",3,true,true),4);
   System.out.println("13 cursor, Unicode, boundary and indentation checks passed");
 }
}
