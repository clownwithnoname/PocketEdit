package app.pocketedit;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.provider.DocumentsContract;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.text.*;
import android.text.style.ForegroundColorSpan;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.util.AtomicFile;
import java.io.*;
import java.nio.*;
import java.nio.charset.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.JSONObject;

public class MainActivity extends Activity {
  final int BG=0xff15191f,PANEL=0xff1b2028,FG=0xffdce3ed,MUTED=0xff8996a6,GREEN=0xff9cccb7;
  final Handler ui=new Handler(Looper.getMainLooper());
  final ExecutorService io=Executors.newSingleThreadExecutor();
  final ExecutorService syntaxWorker=Executors.newSingleThreadExecutor();
  final ExecutorService previewWorker=Executors.newSingleThreadExecutor();
  Future<?> syntaxJob,previewJob; int revision=0; boolean wrapping=true;
  String cachedText=""; int[] lineStarts={0}; Typeface unifont;
  static final String[] FONTS={"Monospace","Unifont","Sans serif","Serif"};
  ArrayList<Syntax.Token> syntaxTokens=new ArrayList<>();
  int paintedStart=-1,paintedEnd=-1; float preferredX=Float.NaN; boolean verticalMove=false;
  Runnable visibleTask=()->applyVisibleSyntax();
  CodeEdit editor; TextView title,status; LinearLayout root,findRow,workArea,hotkeys; EditText query;
  WebView preview; Button previewButton; Switch liveToggle;
  boolean previewVisible=false,livePreview=false,crashedLastRun=false;
  String lastBackupKey="",lastBackupDigest="";boolean backupFailureShown=false;
  final Runnable previewTask=()->renderPreview(),backupTask=new Runnable(){@Override public void run(){backupNow(false);scheduleBackup();}};
  Uri fileUri; String filename="untitled.md",language="Auto",encoding="UTF-8",lineEnding="\n"; boolean bom=false,dirty=false,changing=false,busy=false,restored=false;
  ArrayDeque<Snapshot> undo=new ArrayDeque<>(),redo=new ArrayDeque<>(); long lastEdit=0; int undoChars=0;
  Runnable highlightTask=()->highlight(),draftTask=()->saveDraft();
  static final String[] LANGS={"Auto","Markdown","HTML","CSS","JavaScript","JSON","Plain text"};
  static class Snapshot {String text;int start,end;Snapshot(String t,int s,int e){text=t;start=s;end=e;}}
  class CodeEdit extends EditText {
    CodeEdit(){super(MainActivity.this);}
    @Override protected void onSelectionChanged(int a,int b){super.onSelectionChanged(a,b);if(!verticalMove)preferredX=Float.NaN;if(status!=null)updateStatus();}
    @Override protected void onScrollChanged(int l,int t,int oldl,int oldt){super.onScrollChanged(l,t,oldl,oldt);queueVisible();}
    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){super.onSizeChanged(w,h,oldw,oldh);queueVisible();}
    @Override public android.view.inputmethod.InputConnection onCreateInputConnection(android.view.inputmethod.EditorInfo info){
      android.view.inputmethod.InputConnection base=super.onCreateInputConnection(info);
      if(base==null)return null;
      return new android.view.inputmethod.InputConnectionWrapper(base,false){
        @Override public CharSequence getTextBeforeCursor(int n,int flags){return super.getTextBeforeCursor(Math.min(n,2048),flags & ~GET_TEXT_WITH_STYLES);}
        @Override public CharSequence getTextAfterCursor(int n,int flags){return super.getTextAfterCursor(Math.min(n,2048),flags & ~GET_TEXT_WITH_STYLES);}
      };
    }
    @Override public boolean onKeyDown(int key,KeyEvent event){
      if(event.isCtrlPressed()&&key==KeyEvent.KEYCODE_Z){history(event.isShiftPressed());return true;}
      if(event.isCtrlPressed()&&key==KeyEvent.KEYCODE_S){save(event.isShiftPressed());return true;}
      if(key==KeyEvent.KEYCODE_TAB){insert("\t");return true;}
      return super.onKeyDown(key,event);
    }
  }
  int dp(float n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
  TextView label(String text,int size,int color){TextView v=new TextView(this);v.setText(text);v.setTextColor(color);v.setTextSize(size);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
  GradientDrawable bg(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(5));return d;}
  Button button(String text,Runnable action){Button b=new Button(this);b.setText(text);b.setTextSize(13);b.setTextColor(FG);b.setAllCaps(false);b.setMinWidth(0);b.setMinimumWidth(0);b.setMinHeight(0);b.setMinimumHeight(0);b.setPadding(dp(10),0,dp(10),0);b.setBackground(bg(PANEL));b.setOnClickListener(v->{if(!busy)action.run();});return b;}
  @Override public void onCreate(Bundle saved){
    super.onCreate(saved);
    File active=new File(getFilesDir(),"session.active"),crash=new File(getFilesDir(),"crash.flag");
    crashedLastRun=active.exists()||crash.exists();crash.delete();active.delete();
    installCrashDetector();
    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);buildUi();restore();
  }
  void buildUi(){
    root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);setContentView(root);
    LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(8),dp(4),dp(8),dp(2));top.setBackgroundColor(PANEL);root.addView(top,new LinearLayout.LayoutParams(-1,dp(49)));
    previewButton=button("Preview",()->togglePreview());previewButton.setContentDescription("Toggle rendered preview");top.addView(previewButton,new LinearLayout.LayoutParams(dp(84),-1));
    livePreview=getPreferences(0).getBoolean("live_preview",false);
    liveToggle=new Switch(this);liveToggle.setText("Live preview");liveToggle.setTextSize(12);liveToggle.setTextColor(FG);liveToggle.setChecked(livePreview);liveToggle.setPadding(dp(8),0,dp(4),0);liveToggle.setContentDescription("Live preview: show editor and rendered output together");
    top.addView(liveToggle,new LinearLayout.LayoutParams(0,-1,1));
    Button settings=button("Settings",()->{});settings.setTextSize(12);settings.setOnClickListener(v->{if(!busy)menu(settings);});top.addView(settings,new LinearLayout.LayoutParams(dp(82),-1));
    liveToggle.setOnCheckedChangeListener((v,checked)->{livePreview=checked;getPreferences(0).edit().putBoolean("live_preview",checked).apply();if(checked)previewVisible=true;updatePreviewLayout();if(checked)renderPreview();});
    LinearLayout files=new LinearLayout(this);files.setGravity(Gravity.CENTER_VERTICAL);files.setPadding(dp(9),0,dp(9),dp(4));files.setBackgroundColor(PANEL);root.addView(files,new LinearLayout.LayoutParams(-1,dp(49)));
    TextView brand=label("Pocket Edit",15,GREEN);brand.setTypeface(null,Typeface.BOLD);files.addView(brand,new LinearLayout.LayoutParams(0,-1,1));
    files.addView(button("Open",()->guard(()->open())),new LinearLayout.LayoutParams(dp(59),-1));
    Button save=button("Save",()->save(false));save.setTextColor(BG);save.setBackground(bg(GREEN));files.addView(save,new LinearLayout.LayoutParams(dp(56),-1));
    Button saveAs=button("Save as",()->save(true));saveAs.setTextSize(12);files.addView(saveAs,new LinearLayout.LayoutParams(dp(75),-1));
    title=label(filename,13,FG);title.setPadding(dp(14),0,dp(14),0);title.setSingleLine();title.setEllipsize(TextUtils.TruncateAt.MIDDLE);title.setContentDescription("File name; tap to rename");title.setOnClickListener(v->{if(!busy)rename();});root.addView(title,new LinearLayout.LayoutParams(-1,dp(40)));
    findRow=new LinearLayout(this);findRow.setPadding(dp(8),0,dp(8),0);query=new EditText(this);query.setSingleLine();query.setTextSize(14);query.setTextColor(FG);query.setHintTextColor(MUTED);query.setHint("Find text…");findRow.addView(query,new LinearLayout.LayoutParams(0,dp(48),1));findRow.addView(button("Next",()->find()));findRow.addView(button("×",()->{findRow.setVisibility(View.GONE);focusEditor();}));findRow.setVisibility(View.GONE);root.addView(findRow);query.setOnEditorActionListener((v,a,e)->{find();return true;});
    editor=new CodeEdit();editor.setTextColor(FG);editor.setTextSize(14);editor.setTypeface(Typeface.MONOSPACE);editor.setGravity(Gravity.TOP|Gravity.LEFT);editor.setBackgroundColor(BG);editor.setPadding(dp(14),dp(12),dp(14),dp(8));editor.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);wrapping=getPreferences(0).getBoolean("wrap",true);editor.setHorizontallyScrolling(!wrapping);editor.setHorizontalScrollBarEnabled(!wrapping);editor.setBreakStrategy(Layout.BREAK_STRATEGY_SIMPLE);editor.setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE);editor.setVerticalScrollBarEnabled(true);editor.setImeOptions(android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI|android.view.inputmethod.EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);editor.setContentDescription("Text editor");workArea=new LinearLayout(this);workArea.setOrientation(LinearLayout.VERTICAL);root.addView(workArea,new LinearLayout.LayoutParams(-1,0,1));workArea.addView(editor,new LinearLayout.LayoutParams(-1,0,1));
    status=label("Ln 1, Col 1",11,MUTED);status.setPadding(dp(14),0,dp(14),0);root.addView(status,new LinearLayout.LayoutParams(-1,dp(26)));
    hotkeys=new LinearLayout(this);LinearLayout keys=hotkeys;keys.setPadding(dp(4),dp(4),dp(4),dp(4));keys.setBackgroundColor(0xff222933);root.addView(keys,new LinearLayout.LayoutParams(-1,dp(44)));
    String[] names={"Home","End","↵","Tab","←","→","↑","↓"};for(int i=0;i<8;i++){final int key=i;Button b=button(names[i],()->action(key,false));b.setPadding(0,0,0,0);b.setTextSize(12);b.setBackground(bg(0xff2d3541));b.setFocusable(false);b.setContentDescription(new String[]{"Home","End","Return","Tab","Left; hold to move by word","Right; hold to move by word","Up; hold to repeat","Down; hold to repeat"}[i]);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(dp(2),0,dp(2),0);keys.addView(b,lp);if(i>=4)holdArrow(b,key);}
    editor.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){if(!changing&&(System.currentTimeMillis()-lastEdit>650||undo.isEmpty()))record();}public void onTextChanged(CharSequence s,int st,int before,int count){}public void afterTextChanged(Editable e){if(!changing){lastEdit=System.currentTimeMillis();redo.clear();dirty=true;schedule();}}});
    previewVisible=livePreview;updatePreviewLayout();
  }
  void holdArrow(Button b,int key){final boolean[] active={false};final Runnable[] repeat={null};repeat[0]=()->{if(active[0]){action(key,true);ui.postDelayed(repeat[0],150);}};
    b.setOnTouchListener((v,e)->{switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN: if(busy)return true;active[0]=true;b.setPressed(true);action(key,false);ui.postDelayed(repeat[0],380);return true;case MotionEvent.ACTION_UP:case MotionEvent.ACTION_CANCEL:active[0]=false;b.setPressed(false);ui.removeCallbacks(repeat[0]);return true;}return true;});
  }
  void focusEditor(){if(!editor.hasFocus()){editor.requestFocus();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(editor,InputMethodManager.SHOW_IMPLICIT);}}
  void action(int key,boolean word){if(busy)return;focusEditor();if(key>=6){moveVertical(key==7);return;}preferredX=Float.NaN;String s=cachedText;int a=Math.max(0,Math.min(editor.getSelectionStart(),editor.getSelectionEnd())),b=Math.max(a,Math.max(editor.getSelectionStart(),editor.getSelectionEnd()));
    if(key==2){insert("\n"+EditorLogic.indentation(s,a));return;}if(key==3){insert("\t");return;}
    int p=key==0?EditorLogic.home(s,a):key==1?EditorLogic.end(s,b):key==4?(a!=b&&!word?a:EditorLogic.move(s,a,false,word)):(a!=b&&!word?b:EditorLogic.move(s,b,true,word));editor.setSelection(p);editor.bringPointIntoView(p);
  }
  void moveVertical(boolean down){
    Layout layout=editor.getLayout();if(layout==null)return;
    int pos=Math.max(0,editor.getSelectionEnd()),line=layout.getLineForOffset(pos),target=line+(down?1:-1);
    if(target<0||target>=layout.getLineCount())return;
    if(Float.isNaN(preferredX))preferredX=layout.getPrimaryHorizontal(pos);
    int dest=layout.getOffsetForHorizontal(target,preferredX);
    int end=layout.getLineEnd(target);if(end>layout.getLineStart(target)&&cachedText.charAt(end-1)=='\n')end--;
    dest=Math.min(dest,end);verticalMove=true;editor.setSelection(dest);verticalMove=false;editor.bringPointIntoView(dest);
  }
  void insert(String text){record();changing=true;int a=Math.max(0,Math.min(editor.getSelectionStart(),editor.getSelectionEnd())),b=Math.max(a,Math.max(editor.getSelectionStart(),editor.getSelectionEnd()));editor.getText().replace(a,b,text);editor.setSelection(a+text.length());changing=false;redo.clear();dirty=true;lastEdit=0;schedule();}
  Snapshot snapshot(){return new Snapshot(editor.getText().toString(),Math.max(0,editor.getSelectionStart()),Math.max(0,editor.getSelectionEnd()));}
  void record(){Snapshot s=snapshot();if(!undo.isEmpty()&&undo.peekLast().text.equals(s.text))return;undo.add(s);undoChars+=s.text.length();while(undo.size()>1&&(undo.size()>100||undoChars>4000000))undoChars-=undo.removeFirst().text.length();}
  void history(boolean forward){ArrayDeque<Snapshot> src=forward?redo:undo,dst=forward?undo:redo;if(src.isEmpty())return;dst.add(snapshot());Snapshot s=src.removeLast();changing=true;editor.setText(s.text);editor.setSelection(Math.min(s.start,s.text.length()),Math.min(s.end,s.text.length()));changing=false;undoChars=0;for(Snapshot n:undo)undoChars+=n.text.length();dirty=true;lastEdit=0;schedule();editor.bringPointIntoView(editor.getSelectionEnd());}
  void schedule(){cacheDocument();updateStatus();ui.removeCallbacks(highlightTask);ui.postDelayed(highlightTask,160);ui.removeCallbacks(draftTask);ui.postDelayed(draftTask,500);if(previewVisible&&livePreview){ui.removeCallbacks(previewTask);ui.postDelayed(previewTask,300);}}
  void cacheDocument(){cachedText=editor.getText().toString();lineStarts=Syntax.lineStarts(cachedText);revision++;syntaxTokens.clear();paintedStart=-1;preferredX=Float.NaN;}
  void updateStatus(){if(editor==null||status==null)return;int p=Math.min(cachedText.length(),Math.max(0,editor.getSelectionStart()));int line=Arrays.binarySearch(lineStarts,p);if(line<0)line=-line-2;line=Math.max(0,line);String value="Ln "+(line+1)+", Col "+(p-lineStarts[line]+1)+"  ·  "+effectiveLanguage()+"  ·  "+(dirty?"Modified":"Saved");if(!value.contentEquals(status.getText()))status.setText(value);String name=(dirty?"●  ":"")+filename;if(!name.contentEquals(title.getText()))title.setText(name);}
  String effectiveLanguage(){if(!language.equals("Auto"))return language;String n=filename.toLowerCase(Locale.ROOT);if(n.matches(".*\\.(md|markdown|mdown)$"))return "Markdown";if(n.matches(".*\\.(html?|xml|svg)$"))return "HTML";if(n.endsWith(".css"))return "CSS";if(n.matches(".*\\.(m?js|jsx|ts|tsx)$"))return "JavaScript";if(n.matches(".*\\.jsonc?$"))return "JSON";return "Plain text";}
  void menu(View anchor){
    PopupMenu p=new PopupMenu(this,anchor);
    String[] labels={"New file","Undo","Redo","Find…","Select all","Working folder…","Backup interval…","Backup copies per file…","Back up now","Restore latest backup…","Language…","Font size…","Word wrap","Editor font…"};
    for(int i=0;i<labels.length;i++)p.getMenu().add(0,i,i,labels[i]);
    p.getMenu().findItem(12).setCheckable(true).setChecked(wrapping);
    p.getMenu().findItem(1).setEnabled(!undo.isEmpty());p.getMenu().findItem(2).setEnabled(!redo.isEmpty());
    p.setOnMenuItemClickListener(item->{switch(item.getItemId()){
      case 0:guard(()->{fileUri=null;filename="untitled.md";encoding="UTF-8";bom=false;lineEnding="\n";language="Auto";setDocument("",false);saveDraft();});break;
      case 1:history(false);break;case 2:history(true);break;
      case 3:findRow.setVisibility(View.VISIBLE);query.requestFocus();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(query,0);break;
      case 4:togglePreviewOff();focusEditor();editor.selectAll();break;
      case 5:chooseWorkingFolder();break;
      case 6:settingNumber("Backup interval (minutes)","0 disables timed backups", "backup_minutes",5,0,1440);break;
      case 7:settingNumber("Backups per file","Oldest backups are deleted first", "backup_count",9,1,100);break;
      case 8:backupNow(true);break;case 9:manualRecovery();break;
      case 10:new AlertDialog.Builder(this).setTitle("Highlighting").setSingleChoiceItems(LANGS,Arrays.asList(LANGS).indexOf(language),(d,w)->{language=LANGS[w];highlight();updateStatus();saveDraft();if(previewVisible)renderPreview();d.dismiss();}).show();break;
      case 11:String[] sizes={"12","14","16","18","20"};new AlertDialog.Builder(this).setTitle("Text size").setItems(sizes,(d,w)->{int size=Integer.parseInt(sizes[w]);editor.setTextSize(size);getPreferences(0).edit().putInt("size",size).apply();}).show();break;
      case 12:wrapping=!wrapping;getPreferences(0).edit().putBoolean("wrap",wrapping).apply();editor.setHorizontallyScrolling(!wrapping);editor.setHorizontalScrollBarEnabled(!wrapping);editor.scrollTo(0,editor.getScrollY());editor.requestLayout();queueVisible();break;
      case 13:new AlertDialog.Builder(this).setTitle("Editor font").setSingleChoiceItems(FONTS,getPreferences(0).getInt("font",0),(d,w)->{getPreferences(0).edit().putInt("font",w).apply();applyFont(w);d.dismiss();}).show();break;
    }return true;});p.show();
  }
  void rename(){EditText input=new EditText(this);input.setSingleLine();input.setText(filename);new AlertDialog.Builder(this).setTitle("File name").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Use name",(d,w)->{String name=input.getText().toString().trim();if(name.isEmpty()||name.contains("/")||name.contains("\\")){message("Choose a valid file name");return;}if(!name.equals(filename)){filename=name;fileUri=null;dirty=true;highlight();updateStatus();saveDraft();if(previewVisible)renderPreview();}}).show();}
  void guard(Runnable r){if(!dirty)r.run();else new AlertDialog.Builder(this).setMessage("Discard unsaved changes?").setNegativeButton("Cancel",null).setPositiveButton("Discard",(d,w)->r.run()).show();}
  void find(){String needle=query.getText().toString();if(needle.isEmpty())return;String s=editor.getText().toString();int p=s.indexOf(needle,Math.max(0,editor.getSelectionEnd()));if(p<0)p=s.indexOf(needle);if(p<0){message("No matches");return;}editor.setSelection(p,p+needle.length());editor.bringPointIntoView(p);}
  void open(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_LOCAL_ONLY,true);setInitialFolder(i);startActivityForResult(i,1);}
  void save(boolean as){if(busy)return;if(as||fileUri==null){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/plain").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,filename).putExtra(Intent.EXTRA_LOCAL_ONLY,true);setInitialFolder(i);startActivityForResult(i,2);}else write(fileUri);}
  void takePermission(Uri uri,Intent data){try{getContentResolver().takePersistableUriPermission(uri,data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION));}catch(Exception ignored){}}
  @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();takePermission(uri,data);if(req==1)load(uri);if(req==2)write(uri);if(req==3)acceptWorkingFolder(uri,data);}
  String displayName(Uri uri){try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())return c.getString(0);}catch(Exception ignored){}return "untitled.txt";}
  void setBusy(boolean value){busy=value;editor.setEnabled(!value);}
  void load(Uri uri){setBusy(true);io.execute(()->{try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new IOException();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){if(out.size()+n>5*1024*1024)throw new IOException("Maximum file size is 5 MB");out.write(buf,0,n);}byte[] b=out.toByteArray();String enc="UTF-8";int skip=0;if(b.length>=3&&(b[0]&255)==239&&(b[1]&255)==187&&(b[2]&255)==191)skip=3;else if(b.length>=2&&(b[0]&255)==255&&(b[1]&255)==254){enc="UTF-16LE";skip=2;}else if(b.length>=2&&(b[0]&255)==254&&(b[1]&255)==255){enc="UTF-16BE";skip=2;}String text=Charset.forName(enc).newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b,skip,b.length-skip)).toString();if(text.indexOf('\0')>=0)throw new IOException("This appears to be a binary file");final String charset=enc,name=displayName(uri);final boolean hasBom=skip>0;ui.post(()->{setBusy(false);fileUri=uri;filename=name;encoding=charset;bom=hasBom;lineEnding=text.contains("\r\n")?"\r\n":text.contains("\r")?"\r":"\n";language="Auto";setDocument(text.replace("\r\n","\n").replace('\r','\n'),false);saveDraft();});}catch(Exception e){ui.post(()->{setBusy(false);message(e instanceof CharacterCodingException?"Unsupported encoding. Use UTF-8 or BOM-marked UTF-16.":e.getMessage()==null?"Could not open file":e.getMessage());});}});}
  void write(Uri uri){setBusy(true);String content=editor.getText().toString().replace("\n",lineEnding),enc=encoding;boolean prefix=bom;io.execute(()->{try{byte[] data=content.getBytes(Charset.forName(enc));try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException();if(prefix){if(enc.equals("UTF-8"))out.write(new byte[]{(byte)239,(byte)187,(byte)191});else if(enc.equals("UTF-16LE"))out.write(new byte[]{(byte)255,(byte)254});else out.write(new byte[]{(byte)254,(byte)255});}out.write(data);out.flush();}String name=displayName(uri);ui.post(()->{setBusy(false);fileUri=uri;filename=name;dirty=false;updateStatus();saveDraft();message("Saved");});}catch(Exception e){ui.post(()->{setBusy(false);message("Could not save. Try Save as…");});}});}
  void setDocument(String text,boolean modified){changing=true;editor.setText(text);editor.setSelection(0);changing=false;undo.clear();redo.clear();undoChars=0;lastEdit=0;dirty=modified;cacheDocument();highlight();updateStatus();if(previewVisible)renderPreview();}
  void saveDraft(){
    if(editor==null||!restored||io.isShutdown())return;
    final String text=cachedText,name=filename,uri=fileUri==null?"":fileUri.toString(),lang=language,enc=encoding,eol=lineEnding;
    final boolean modified=dirty,hasBom=bom;final int cursor=Math.max(0,editor.getSelectionStart());
    io.execute(()->{AtomicFile f=new AtomicFile(new File(getFilesDir(),"draft.json"));FileOutputStream out=null;
      try{JSONObject d=new JSONObject();d.put("text",text);d.put("name",name);d.put("uri",uri);d.put("dirty",modified);d.put("language",lang);d.put("encoding",enc);d.put("bom",hasBom);d.put("eol",eol);d.put("cursor",cursor);
        out=f.startWrite();out.write(d.toString().getBytes(StandardCharsets.UTF_8));f.finishWrite(out);
      }catch(Exception e){if(out!=null)f.failWrite(out);ui.post(()->message("Could not save recovery draft"));}
    });
  }
  void restore(){applyFont(getPreferences(0).getInt("font",0));editor.setTextSize(getPreferences(0).getInt("size",14));setBusy(true);io.execute(()->{JSONObject data=null;try{byte[] b=new AtomicFile(new File(getFilesDir(),"draft.json")).readFully();data=new JSONObject(new String(b,StandardCharsets.UTF_8));}catch(Exception ignored){}final JSONObject d=data;ui.post(()->{restored=true;setBusy(false);if(d!=null){filename=d.optString("name","untitled.md");String uri=d.optString("uri","");fileUri=uri.isEmpty()?null:Uri.parse(uri);language=d.optString("language","Auto");encoding=d.optString("encoding","UTF-8");lineEnding=d.optString("eol","\n");bom=d.optBoolean("bom",false);setDocument(d.optString("text",""),d.optBoolean("dirty",true));editor.setSelection(Math.max(0,Math.min(d.optInt("cursor",0),editor.length())));}else setDocument("",false);if(previewVisible)renderPreview();scheduleBackup();if(crashedLastRun)considerCrashRecovery();});});}
  @Override protected void onPause(){super.onPause();ui.removeCallbacks(draftTask);saveDraft();}
  void message(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}

  // Preview: a static rendered view, or a simultaneous editor/output split while Live is on.
  void initPreview(){
    if(preview!=null)return;
    preview=new WebView(this);preview.setBackgroundColor(BG);
    WebSettings config=preview.getSettings();config.setJavaScriptEnabled(false);config.setAllowFileAccess(false);config.setAllowContentAccess(false);
    config.setBlockNetworkLoads(true);config.setBlockNetworkImage(true);config.setDomStorageEnabled(false);
    config.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    preview.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view,String url){return true;}
      @Override public boolean shouldOverrideUrlLoading(WebView view,android.webkit.WebResourceRequest request){return true;}
    });
    preview.setContentDescription("Rendered document preview; network access disabled");
    workArea.addView(preview,new LinearLayout.LayoutParams(-1,0,1));
  }
  void togglePreview(){previewVisible=!previewVisible;updatePreviewLayout();if(previewVisible)renderPreview();else focusEditor();}
  void togglePreviewOff(){if(!previewVisible)return;previewVisible=false;updatePreviewLayout();}
  void updatePreviewLayout(){
    if(previewVisible)initPreview();
    editor.setVisibility(!previewVisible||livePreview?View.VISIBLE:View.GONE);
    if(preview!=null)preview.setVisibility(previewVisible?View.VISIBLE:View.GONE);
    if(hotkeys!=null)hotkeys.setVisibility(!previewVisible||livePreview?View.VISIBLE:View.GONE);
    if(previewButton!=null){previewButton.setBackground(bg(previewVisible?GREEN:PANEL));previewButton.setTextColor(previewVisible?BG:FG);}
    if(previewVisible&&!livePreview){((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(editor.getWindowToken(),0);editor.clearFocus();}
    if(previewVisible&&livePreview)editor.requestFocus();
    workArea.requestLayout();
  }
  void renderPreview(){
    if(!previewVisible||preview==null||editor==null||!restored)return;
    final String source=cachedText,lang=effectiveLanguage();final int generation=revision;
    if(previewJob!=null)previewJob.cancel(true);
    previewJob=previewWorker.submit(()->{
      final String html=lang.equals("Markdown")?MarkdownPreview.html(source):lang.equals("HTML")?source:MarkdownPreview.plain(source);
      if(Thread.currentThread().isInterrupted())return;
      ui.post(()->{if(!previewVisible||generation!=revision||!lang.equals(effectiveLanguage()))return;preview.loadDataWithBaseURL("about:blank",html,"text/html","UTF-8",null);});
    });
  }
  void setInitialFolder(Intent intent){String s=getPreferences(0).getString("working_tree","");if(!s.isEmpty()){
    try{intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI,Uri.parse(s));}catch(Exception ignored){}
  }}
  void chooseWorkingFolder(){
    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
    i.putExtra(Intent.EXTRA_LOCAL_ONLY,true);setInitialFolder(i);startActivityForResult(i,3);
  }
  void acceptWorkingFolder(Uri tree,Intent data){
    try{getContentResolver().takePersistableUriPermission(tree,Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);}
    catch(Exception e){message("Persistent folder access was not granted");return;}
    io.execute(()->{try{
      BackupStore.checkFolder(getContentResolver(),tree);
      BackupStore.bak(getContentResolver(),tree,true);
      ui.post(()->{getPreferences(0).edit().putString("working_tree",tree.toString()).apply();
        lastBackupKey="";lastBackupDigest="";backupFailureShown=false;
        message("Working folder selected; /bak ready");backupNow(true);
      });
    }catch(Exception e){ui.post(()->message("Folder unavailable: "+e.getMessage()));}});
  }
  void settingNumber(String heading,String explanation,String pref,int defaultValue,int min,int max){
    EditText edit=new EditText(this);edit.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
    edit.setSingleLine();edit.setText(String.valueOf(getPreferences(0).getInt(pref,defaultValue)));edit.setSelectAllOnFocus(true);
    LinearLayout box=new LinearLayout(this);box.setPadding(dp(24),0,dp(24),0);box.addView(edit,new LinearLayout.LayoutParams(-1,dp(50)));
    new AlertDialog.Builder(this).setTitle(heading).setMessage(explanation).setView(box).setNegativeButton("Cancel",null)
      .setPositiveButton("Apply",(d,w)->{try{int n=Integer.parseInt(edit.getText().toString().trim());
        if(n<min||n>max){message("Value must be "+min+"–"+max);return;}
        getPreferences(0).edit().putInt(pref,n).apply();if(pref.equals("backup_minutes"))scheduleBackup();
        message("Saved");
      }catch(NumberFormatException e){message("Enter a number");}}).show();
  }
  void scheduleBackup(){ui.removeCallbacks(backupTask);int min=getPreferences(0).getInt("backup_minutes",5);
    if(min>0&&restored)ui.postDelayed(backupTask,min*60_000L);
  }
  void backupNow(boolean forced){
    if(!restored||busy)return;
    String treeName=getPreferences(0).getString("working_tree","");
    if(treeName.isEmpty()){if(forced)message("Select a working folder in Settings first");return;}
    final Uri tree=Uri.parse(treeName);final String text=cachedText,name=filename,source=fileUri==null?"":fileUri.toString();
    if(!forced&&text.isEmpty()&&source.isEmpty())return;
    final String hash=BackupStore.signature(text),key=treeName+"/"+BackupStore.prefix(name,source);
    if(!forced&&key.equals(lastBackupKey)&&hash.equals(lastBackupDigest))return;
    int count=getPreferences(0).getInt("backup_count",9);
    io.execute(()->{try{
      BackupStore.save(getContentResolver(),tree,name,source,text,count);
      AtomicFile index=new AtomicFile(new File(getFilesDir(),"backup-index.json"));FileOutputStream out=null;
      try{JSONObject d=new JSONObject().put("tree",treeName).put("name",name).put("source",source);
        out=index.startWrite();out.write(d.toString().getBytes(StandardCharsets.UTF_8));index.finishWrite(out);
      }catch(Exception e){if(out!=null)index.failWrite(out);}
      ui.post(()->{lastBackupKey=key;lastBackupDigest=hash;backupFailureShown=false;if(forced)message("Backup saved to /bak");});
    }catch(Exception e){ui.post(()->{if(forced||!backupFailureShown)message("Backup failed: "+e.getMessage());backupFailureShown=true;});}});
  }
  void manualRecovery(){findRecovery(false);}
  void considerCrashRecovery(){crashedLastRun=false;findRecovery(true);}
  void findRecovery(boolean afterCrash){
    setBusy(true);
    String location=getPreferences(0).getString("working_tree","");
    final String name=filename,source=fileUri==null?"":fileUri.toString();
    final boolean noDraft=source.isEmpty()&&name.equals("untitled.md")&&cachedText.isEmpty();
    io.execute(()->{
      String folder=location,candidateName=name,candidateSource=source;
      if(noDraft){try{JSONObject index=new JSONObject(new String(new AtomicFile(new File(getFilesDir(),"backup-index.json")).readFully(),StandardCharsets.UTF_8));
        folder=index.optString("tree",folder);candidateName=index.optString("name",name);candidateSource=index.optString("source",source);
      }catch(Exception ignored){}}
      BackupStore.Candidate found=null;String error=null;
      try{if(!folder.isEmpty())found=BackupStore.latestValid(getContentResolver(),Uri.parse(folder),candidateName,candidateSource);}
      catch(Exception e){error=e.getMessage();}
      final BackupStore.Candidate backup=found;final String recoveredName=candidateName,recoveredSource=candidateSource,problem=error;
      ui.post(()->{
        setBusy(false);
        if(backup==null){if(!afterCrash)message(problem!=null?"Cannot read backups: "+problem:"No valid backups for this file");return;}
        String explanation="Latest valid /bak copy for "+recoveredName+". Restore this version as an unsaved document?";
        new AlertDialog.Builder(this).setTitle(afterCrash?"Recover after crash":"Restore backup")
          .setMessage(explanation).setNegativeButton(afterCrash?"Keep current draft":"Cancel",null)
          .setPositiveButton("Restore backup",(d,w)->{
            filename=recoveredName;fileUri=recoveredSource.isEmpty()?null:Uri.parse(recoveredSource);
            setDocument(backup.text,true);saveDraft();
            message("Backup restored. Save to keep changes.");
          }).show();
      });
    });
  }
  void installCrashDetector(){
    final Thread.UncaughtExceptionHandler previous=Thread.getDefaultUncaughtExceptionHandler();
    Thread.setDefaultUncaughtExceptionHandler((thread,error)->{
      try(FileOutputStream file=new FileOutputStream(new File(getFilesDir(),"crash.flag"))){file.write(1);file.flush();}catch(Exception ignored){}
      if(previous!=null)previous.uncaughtException(thread,error);else System.exit(10);
    });
  }
  @Override public void onBackPressed(){if(previewVisible){togglePreviewOff();return;}super.onBackPressed();}
  @Override protected void onResume(){super.onResume();
    try(FileOutputStream file=new FileOutputStream(new File(getFilesDir(),"session.active"))){file.write(1);}catch(IOException ignored){}
    scheduleBackup();
  }
  @Override protected void onStop(){ui.removeCallbacks(backupTask);new File(getFilesDir(),"session.active").delete();super.onStop();}

  void applyFont(int choice){
    if(choice==1){if(unifont!=null){editor.setTypeface(unifont);return;}io.execute(()->{try{Typeface face=Typeface.createFromAsset(getAssets(),"fonts/Unifont.otf");ui.post(()->{unifont=face;if(getPreferences(0).getInt("font",0)==1){editor.setTypeface(face);queueVisible();}});}catch(Exception e){ui.post(()->message("Could not load Unifont"));}});}
    else editor.setTypeface(choice==2?Typeface.SANS_SERIF:choice==3?Typeface.SERIF:Typeface.MONOSPACE);
    preferredX=Float.NaN;paintedStart=-1;queueVisible();
  }
  static class SyntaxSpan extends ForegroundColorSpan {SyntaxSpan(int c){super(c);}}
  void highlight(){
    if(editor==null)return;
    final String text=cachedText,lang=effectiveLanguage();final int generation=revision;
    if(syntaxJob!=null)syntaxJob.cancel(true);
    syntaxJob=syntaxWorker.submit(()->{
      ArrayList<Syntax.Token> result=Syntax.scan(text,lang);
      if(Thread.currentThread().isInterrupted())return;
      ui.post(()->{if(generation!=revision||!lang.equals(effectiveLanguage()))return;syntaxTokens=result;paintedStart=-1;applyVisibleSyntax();});
    });
  }
  void queueVisible(){if(ui==null||visibleTask==null)return;ui.removeCallbacks(visibleTask);ui.postDelayed(visibleTask,60);}
  void applyVisibleSyntax(){
    if(editor==null||editor.getLayout()==null)return;
    Layout l=editor.getLayout();int top=Math.max(0,editor.getScrollY()-editor.getTotalPaddingTop());
    int first=Math.max(0,l.getLineForVertical(top)-8),last=Math.min(l.getLineCount()-1,l.getLineForVertical(top+editor.getHeight())+8);
    int start=l.getLineStart(first),end=l.getLineEnd(last);
    if(start==paintedStart&&end==paintedEnd)return;paintedStart=start;paintedEnd=end;
    Editable e=editor.getText();editor.beginBatchEdit();
    try{for(SyntaxSpan span:e.getSpans(0,e.length(),SyntaxSpan.class))e.removeSpan(span);
      int low=0,high=syntaxTokens.size();while(low<high){int mid=(low+high)>>>1;if(syntaxTokens.get(mid).end<=start)low=mid+1;else high=mid;}
      for(int i=low;i<syntaxTokens.size();i++){Syntax.Token t=syntaxTokens.get(i);if(t.start>=end)break;int a=Math.max(start,t.start),b=Math.min(end,t.end);if(a<b&&b<=e.length())e.setSpan(new SyntaxSpan(t.color),a,b,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}
    }finally{editor.endBatchEdit();}
  }
  @Override protected void onDestroy(){ui.removeCallbacksAndMessages(null);if(syntaxJob!=null)syntaxJob.cancel(true);if(previewJob!=null)previewJob.cancel(true);syntaxWorker.shutdownNow();previewWorker.shutdownNow();io.shutdown();if(preview!=null){workArea.removeView(preview);preview.destroy();}super.onDestroy();}
}
