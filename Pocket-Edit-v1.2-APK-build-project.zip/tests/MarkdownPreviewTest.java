import app.pocketedit.MarkdownPreview;
public class MarkdownPreviewTest {
 static void check(boolean yes){if(!yes)throw new AssertionError();}
 public static void main(String[] args){
   String html=MarkdownPreview.html("# Heading\n\n**bold** and `code`\n\n- [x] Done\n- [ ] Todo\n\n| A | B |\n|---|---|\n| one | two |\n\n```js\n<x>&\n```\n");
   check(html.contains("<h1>Heading</h1>"));check(html.contains("<strong>bold</strong>"));
   check(html.contains("<code>code</code>"));check(html.contains("☑"));check(html.contains("<table>"));
   check(html.contains("&lt;x&gt;&amp;"));check(!html.contains("<x>"));
   check(MarkdownPreview.html("<script>alert(1)</script>").contains("&lt;script&gt;"));
   check(!MarkdownPreview.html("[foo](javascript:evil())").contains("href="));
   System.out.println("Markdown preview tests passed");
 }
}
