package app.pocketedit;

import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Small offline, escaping Markdown renderer. Does not load external resources or execute HTML. */
public final class MarkdownPreview {
  private MarkdownPreview() {}
  private static final Pattern HEADING=Pattern.compile("^ {0,3}(#{1,6})\\s+(.+?)\\s*#*\\s*$");
  private static final Pattern BULLET=Pattern.compile("^ {0,3}([-+*]|[0-9]+[.)])\\s+(.*)$");
  private static final Pattern TASK=Pattern.compile("^\\[([ xX])\\]\\s+(.*)$");
  private static final Pattern RULE=Pattern.compile("^ {0,3}(?:[-]\\s*){3,}$|^ {0,3}(?:[*]\\s*){3,}$|^ {0,3}(?:[_]\\s*){3,}$");
  private static final String CSS="*{box-sizing:border-box}body{background:#15191f;color:#dce3ed;font-family:system-ui,sans-serif;line-height:1.65;font-size:15px;padding:6px 16px 60px;max-width:900px;margin:auto;overflow-wrap:anywhere}h1,h2,h3,h4,h5,h6{line-height:1.3;color:#c3e4d6;margin:1.25em 0 .4em}h1{font-size:1.9em;border-bottom:1px solid #37414c;padding-bottom:.3em}h2{font-size:1.5em;border-bottom:1px solid #303943;padding-bottom:.2em}h3{font-size:1.23em}p{margin:.65em 0}a,.link{color:#88c5ed}code,pre{font-family:monospace;background:#252d38;color:#d6e7c6}code{padding:2px 4px;border-radius:3px}pre{padding:13px;border-radius:6px;overflow-x:auto;white-space:pre}pre code{padding:0}blockquote{border-left:3px solid #729c90;color:#b6c7d6;margin:1em 0;padding:0 1em}ul,ol{padding-left:1.6em}li{margin:.2em 0}hr{border:none;border-top:1px solid #404d58;margin:1.5em 0}table{border-collapse:collapse;display:block;overflow-x:auto;width:max-content;max-width:100%;margin:1em 0}th,td{border:1px solid #44505d;padding:6px 10px;text-align:left}th{background:#27323a}.task{list-style:none;margin-left:-1.4em}.box{font-family:monospace;color:#9cccb7;margin-right:.5em}.image{color:#8f9eac;font-style:italic}";

  public static String html(String markdown) {
    if(markdown==null)markdown="";
    String[] lines=markdown.replace("\r\n","\n").replace('\r','\n').split("\n",-1);
    StringBuilder b=new StringBuilder(Math.min(markdown.length()*2+500,200000));
    b.append("<!doctype html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><meta charset=\"utf-8\"><style>").append(CSS).append("</style></head><body>");
    boolean code=false,inList=false,ordered=false,paragraph=false,quote=false;
    for(int i=0;i<lines.length;i++){
      String line=lines[i];String trim=line.trim();
      if(trim.startsWith("```")||trim.startsWith("~~~")) {
        if(paragraph){b.append("</p>");paragraph=false;}
        if(inList){b.append(ordered?"</ol>":"</ul>");inList=false;}
        if(quote){b.append("</blockquote>");quote=false;}
        if(code){b.append("</code></pre>");code=false;}else{b.append("<pre><code>");code=true;}
        continue;
      }
      if(code){b.append(escape(line)).append('\n');continue;}
      if(trim.length()==0){if(paragraph){b.append("</p>");paragraph=false;}if(inList){b.append(ordered?"</ol>":"</ul>");inList=false;}if(quote){b.append("</blockquote>");quote=false;}continue;}
      if(trim.startsWith(">")) {
        if(paragraph){b.append("</p>");paragraph=false;}if(inList){b.append(ordered?"</ol>":"</ul>");inList=false;}
        if(!quote){b.append("<blockquote>");quote=true;}
        b.append("<p>").append(inline(trim.substring(1).trim(),0)).append("</p>");continue;
      }
      if(quote){b.append("</blockquote>");quote=false;}
      Matcher h=HEADING.matcher(line),li=BULLET.matcher(line);
      if(h.matches()){
        if(paragraph){b.append("</p>");paragraph=false;}if(inList){b.append(ordered?"</ol>":"</ul>");inList=false;}
        int level=h.group(1).length();b.append("<h").append(level).append('>').append(inline(h.group(2),0)).append("</h").append(level).append('>');continue;
      }
      if(RULE.matcher(line).matches()){
        if(paragraph){b.append("</p>");paragraph=false;}if(inList){b.append(ordered?"</ol>":"</ul>");inList=false;}b.append("<hr>");continue;
      }
      if(isTableStart(lines,i)){
        if(paragraph){b.append("</p>");paragraph=false;}if(inList){b.append(ordered?"</ol>":"</ul>");inList=false;}
        b.append("<table><thead><tr>");for(String c:cells(lines[i]))b.append("<th>").append(inline(c,0)).append("</th>");b.append("</tr></thead><tbody>");i+=2;
        for(;i<lines.length&&lines[i].contains("|")&&!lines[i].trim().isEmpty();i++){
          b.append("<tr>");for(String c:cells(lines[i]))b.append("<td>").append(inline(c,0)).append("</td>");b.append("</tr>");
        }
        b.append("</tbody></table>");i--;continue;
      }
      if(li.matches()){
        if(paragraph){b.append("</p>");paragraph=false;}
        boolean numbered=Character.isDigit(li.group(1).charAt(0));
        if(inList&&numbered!=ordered){b.append(ordered?"</ol>":"</ul>");inList=false;}
        if(!inList){ordered=numbered;b.append(ordered?"<ol>":"<ul>");inList=true;}
        Matcher task=TASK.matcher(li.group(2));
        if(task.matches())b.append("<li class=\"task\"><span class=\"box\">").append(task.group(1).equals(" ")?"☐":"☑").append("</span>").append(inline(task.group(2),0)).append("</li>");
        else b.append("<li>").append(inline(li.group(2),0)).append("</li>");
        continue;
      }
      if(inList){b.append(ordered?"</ol>":"</ul>");inList=false;}
      if(!paragraph){b.append("<p>");paragraph=true;}else b.append(' ');
      b.append(inline(trim,0));
    }
    if(paragraph)b.append("</p>");if(inList)b.append(ordered?"</ol>":"</ul>");if(quote)b.append("</blockquote>");if(code)b.append("</code></pre>");
    return b.append("</body></html>").toString();
  }
  private static boolean isTableStart(String[] lines,int i){if(i+1>=lines.length||!lines[i].contains("|")||!lines[i+1].contains("-"))return false;
    String next=lines[i+1].trim().replace("|","").replace(":","").replace("-","").replace(" ","");return next.isEmpty()&&lines[i+1].contains("---");}
  private static ArrayList<String> cells(String line){String text=line.trim();if(text.startsWith("|"))text=text.substring(1);if(text.endsWith("|"))text=text.substring(0,text.length()-1);ArrayList<String> result=new ArrayList<>();for(String s:text.split("(?<!\\\\)\\|",-1))result.add(s.trim().replace("\\|","|"));return result;}
  private static String escape(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");}
  private static String inline(String s,int depth) {
    if(depth>8)return escape(s);
    StringBuilder b=new StringBuilder();
    for(int i=0;i<s.length();){
      char c=s.charAt(i);
      if(c=='\\'&&i+1<s.length()){b.append(escape(s.substring(i+1,i+2)));i+=2;continue;}
      if(c=='`'){int n=1;while(i+n<s.length()&&s.charAt(i+n)=='`')n++;String mark=s.substring(i,i+n);int end=s.indexOf(mark,i+n);if(end>=0){b.append("<code>").append(escape(s.substring(i+n,end))).append("</code>");i=end+n;continue;}}
      if(c=='['||(c=='!'&&i+1<s.length()&&s.charAt(i+1)=='[')){
        boolean image=c=='!';int start=i+(image?2:1),end=s.indexOf(']',start);
        if(end>=0&&end+1<s.length()&&s.charAt(end+1)=='('){int close=s.indexOf(')',end+2);if(close>=0){String label=s.substring(start,end);b.append(image?"<span class=\"image\">[Image: ":"<span class=\"link\">").append(inline(label,depth+1)).append(image?"]</span>":"</span>");i=close+1;continue;}}
      }
      String mark=null,tag=null;
      for(String m:new String[]{"**","__","~~","*","_"})if(s.startsWith(m,i)){mark=m;tag=m.equals("~~")?"del":m.length()==2?"strong":"em";break;}
      if(mark!=null){int end=s.indexOf(mark,i+mark.length());if(end>i+mark.length()){b.append('<').append(tag).append('>').append(inline(s.substring(i+mark.length(),end),depth+1)).append("</").append(tag).append('>');i=end+mark.length();continue;}}
      b.append(escape(s.substring(i,i+1)));i++;
    }
    return b.toString();
  }
  public static String plain(String text){return "<!doctype html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><style>body{background:#15191f;color:#dce3ed;margin:14px}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:14px/1.5 monospace}</style></head><body><pre>"+escape(text)+"</pre></body></html>";}
}
