package app.pocketedit;

public final class EditorLogic {
  private static int kind(int c) { return Character.isWhitespace(c)?0:(Character.isLetterOrDigit(c)||c=='_'||c=='$'?1:2); }
  public static int move(String s,int p,boolean right,boolean word) {
    p=Math.max(0,Math.min(p,s.length()));
    if(!word) return right?(p<s.length()?s.offsetByCodePoints(p,1):p):(p>0?s.offsetByCodePoints(p,-1):p);
    if(right) {
      while(p<s.length()&&kind(s.codePointAt(p))==0)p=s.offsetByCodePoints(p,1);
      if(p<s.length()){int k=kind(s.codePointAt(p));while(p<s.length()&&kind(s.codePointAt(p))==k)p=s.offsetByCodePoints(p,1);}
    } else {
      while(p>0&&kind(s.codePointBefore(p))==0)p=s.offsetByCodePoints(p,-1);
      if(p>0){int k=kind(s.codePointBefore(p));while(p>0&&kind(s.codePointBefore(p))==k)p=s.offsetByCodePoints(p,-1);}
    }
    return p;
  }
  public static int home(String s,int p){return p<=0?0:s.lastIndexOf('\n',p-1)+1;}
  public static int end(String s,int p){int n=s.indexOf('\n',p);return n<0?s.length():n;}
  public static String indentation(String s,int p){int start=home(s,p),i=start;while(i<p&&(s.charAt(i)==' '||s.charAt(i)=='\t'))i++;return s.substring(start,i);}
}
