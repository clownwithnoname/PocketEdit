#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_JAR:?Set ANDROID_JAR to platforms/android-35/android.jar}"
: "${ANDROID_BUILD_TOOLS:?Set ANDROID_BUILD_TOOLS to build-tools/35.0.0}"
rm -rf build/classes build/dex
mkdir -p build/classes build/dex
if command -v javac >/dev/null; then
  javac -source 8 -target 8 -encoding UTF-8 -classpath "$ANDROID_JAR" -d build/classes src/app/pocketedit/*.java tests/*.java
else
  : "${ECJ_JAR:?Set ECJ_JAR to Eclipse Java compiler jar}"
  java -jar "$ECJ_JAR" -8 -encoding UTF-8 -classpath "$ANDROID_JAR" -d build/classes src/app/pocketedit/*.java tests/*.java
fi
java -cp build/classes EditorLogicTest
java -cp build/classes SyntaxTest
java -cp build/classes MarkdownPreviewTest
"$ANDROID_BUILD_TOOLS/aapt" package -f -M AndroidManifest.xml -S res -A assets -I "$ANDROID_JAR" -F build/base.apk
"$ANDROID_BUILD_TOOLS/d8" --lib "$ANDROID_JAR" --min-api 26 --output build/dex build/classes/app/pocketedit/*.class
cp build/base.apk build/unsigned.apk
(cd build/dex && zip -q -u ../unsigned.apk classes.dex)
"$ANDROID_BUILD_TOOLS/zipalign" -f 4 build/unsigned.apk build/aligned.apk
"$ANDROID_BUILD_TOOLS/apksigner" sign --ks pocket-edit.keystore --ks-key-alias pocketedit --ks-pass pass:pocket-edit-local --out build/Pocket-Edit-1.2.apk build/aligned.apk
"$ANDROID_BUILD_TOOLS/apksigner" verify --verbose build/Pocket-Edit-1.2.apk
"$ANDROID_BUILD_TOOLS/aapt" dump permissions build/Pocket-Edit-1.2.apk
