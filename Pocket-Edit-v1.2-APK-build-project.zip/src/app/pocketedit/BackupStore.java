package app.pocketedit;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.*;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;

/** Versioned UTF-8 snapshots stored in a user-selected Android document tree's /bak folder. */
public final class BackupStore {
  private static final int MAX_BYTES=5*1024*1024;
  public static class Candidate {public final String text,name;public final Uri uri;Candidate(String t,String n,Uri u){text=t;name=n;uri=u;}}
  static class Entry {final String name;final Uri uri;Entry(String n,Uri u){name=n;uri=u;}}
  private BackupStore() {}
  static String digest(byte[] data){try{MessageDigest md=MessageDigest.getInstance("SHA-256");byte[] hash=md.digest(data);StringBuilder out=new StringBuilder();for(int i=0;i<8;i++)out.append(String.format(Locale.US,"%02x",hash[i]&0xff));return out.toString();}catch(Exception e){throw new IllegalStateException(e);}}
  public static String signature(String text){return digest(text.getBytes(StandardCharsets.UTF_8));}
  static String prefix(String name,String sourceUri){
    String clean=name.replaceAll("[^a-zA-Z0-9._-]","_");if(clean.length()>54)clean=clean.substring(0,54);if(clean.length()==0)clean="untitled";
    String identity=sourceUri==null||sourceUri.isEmpty()?"new:"+name:sourceUri;
    return clean+"~"+digest(identity.getBytes(StandardCharsets.UTF_8))+"~";
  }
  static Uri document(Uri tree){return DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));}
  static ArrayList<Entry> children(ContentResolver resolver,Uri tree,Uri folder)throws IOException {
    ArrayList<Entry> result=new ArrayList<>();Uri lookup=DocumentsContract.buildChildDocumentsUriUsingTree(tree,DocumentsContract.getDocumentId(folder));
    try(Cursor c=resolver.query(lookup,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE},null,null,null)){
      if(c==null)throw new IOException("Folder cannot be listed");
      while(c.moveToNext()){String id=c.getString(0),name=c.getString(1);if(name!=null)result.add(new Entry(name,DocumentsContract.buildDocumentUriUsingTree(tree,id)));}
    }catch(SecurityException e){throw new IOException("Working folder access expired",e);}
    return result;
  }
  static Uri bak(ContentResolver resolver,Uri tree,boolean create)throws IOException {
    if(tree==null)throw new IOException("Choose a working folder in Settings");
    Uri root=document(tree);
    for(Entry e:children(resolver,tree,root))if(e.name.equals("bak")){
      try(Cursor c=resolver.query(e.uri,new String[]{DocumentsContract.Document.COLUMN_MIME_TYPE},null,null,null)){
        if(c!=null&&c.moveToFirst()&&DocumentsContract.Document.MIME_TYPE_DIR.equals(c.getString(0)))return e.uri;
      }
      throw new IOException("A file named bak already exists in the working folder");
    }
    if(!create)return null;
    Uri folder=DocumentsContract.createDocument(resolver,root,DocumentsContract.Document.MIME_TYPE_DIR,"bak");
    if(folder==null)throw new IOException("Cannot create /bak in this folder");
    return folder;
  }
  public static void checkFolder(ContentResolver resolver,Uri tree)throws IOException {children(resolver,tree,document(tree));}
  public static String save(ContentResolver resolver,Uri tree,String name,String sourceUri,String text,int limit)throws IOException {
    if(name==null||name.isEmpty())name="untitled.txt";
    byte[] bytes=text.getBytes(StandardCharsets.UTF_8);
    if(bytes.length>MAX_BYTES)throw new IOException("Backup exceeds 5 MB limit");
    Uri folder=bak(resolver,tree,true);
    String prefix=prefix(name,sourceUri),hash=digest(bytes);
    String timestamp=new SimpleDateFormat("yyyyMMdd-HHmmss-SSS",Locale.US).format(new Date());
    String filename=prefix+timestamp+"~"+hash+".bak";
    // Avoid same-millisecond collisions on providers that don't rename duplicates consistently.
    ArrayList<Entry> existing=children(resolver,tree,folder);
    for(Entry e:existing)if(e.name.equals(filename))return hash;
    Uri created=DocumentsContract.createDocument(resolver,folder,"application/octet-stream",filename);
    if(created==null)throw new IOException("Cannot create backup file");
    try{
      try(OutputStream out=resolver.openOutputStream(created,"wt")){if(out==null)throw new IOException("Backup output unavailable");out.write(bytes);out.flush();}
      byte[] checked=readBytes(resolver,created);
      if(!Arrays.equals(bytes,checked))throw new IOException("Backup verification failed");
    }catch(Exception e){try{DocumentsContract.deleteDocument(resolver,created);}catch(Exception ignored){}throw e instanceof IOException?(IOException)e:new IOException("Backup failed",e);}
    try{prune(resolver,tree,folder,prefix,Math.max(1,limit));}catch(Exception ignored){} // never delete a newly successful backup because pruning is unsupported
    return hash;
  }
  static void prune(ContentResolver resolver,Uri tree,Uri folder,String prefix,int keep)throws IOException {
    ArrayList<Entry> matches=new ArrayList<>();for(Entry e:children(resolver,tree,folder))if(e.name.startsWith(prefix)&&e.name.endsWith(".bak"))matches.add(e);
    Collections.sort(matches,(a,b)->b.name.compareTo(a.name));
    for(int i=keep;i<matches.size();i++){
      try{DocumentsContract.deleteDocument(resolver,matches.get(i).uri);}catch(Exception ignored){}
    }
  }
  public static Candidate latestValid(ContentResolver resolver,Uri tree,String name,String sourceUri)throws IOException {
    Uri folder=bak(resolver,tree,false);if(folder==null)return null;
    String prefix=prefix(name,sourceUri);ArrayList<Entry> matches=new ArrayList<>();
    for(Entry e:children(resolver,tree,folder))if(e.name.startsWith(prefix)&&e.name.endsWith(".bak"))matches.add(e);
    Collections.sort(matches,(a,b)->b.name.compareTo(a.name));
    for(Entry e:matches){
      try{
        String expected=e.name.substring(e.name.lastIndexOf('~')+1,e.name.length()-4);
        byte[] data=readBytes(resolver,e.uri);
        if(!expected.equals(digest(data)))continue;
        String text=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(data)).toString();
        if(text.indexOf('\0')>=0)continue;
        return new Candidate(text,e.name,e.uri);
      }catch(Exception ignored){} // corrupt/unreadable snapshot: try the older one
    }
    return null;
  }
  static byte[] readBytes(ContentResolver resolver,Uri uri)throws IOException {
    try(InputStream in=resolver.openInputStream(uri)){
      if(in==null)throw new IOException("Cannot read backup");ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int count;
      while((count=in.read(buf))!=-1){if(out.size()+count>MAX_BYTES)throw new IOException("Backup too large");out.write(buf,0,count);}return out.toByteArray();
    }
  }
}
